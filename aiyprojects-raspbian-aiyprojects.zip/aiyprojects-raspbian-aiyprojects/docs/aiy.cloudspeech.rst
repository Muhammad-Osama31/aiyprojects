aiy.cloudspeech
===============

.. automodule:: aiy.cloudspeech
    :members:
    :undoc-members:
    :show-inheritance:
