aiy.toneplayer
==============

.. automodule:: aiy.toneplayer
    :members:
    :undoc-members:
    :show-inheritance: