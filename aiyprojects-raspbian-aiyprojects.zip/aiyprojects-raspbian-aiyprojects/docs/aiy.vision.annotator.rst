aiy.vision.annotator
====================

.. automodule:: aiy.vision.annotator
    :members:
    :undoc-members:
    :show-inheritance: